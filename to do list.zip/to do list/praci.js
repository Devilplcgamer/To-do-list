const inputb = document.getElementById("input-box");
const listc = document.getElementById("listc");

function addtask() {
    if (inputb.value === '') {
        alert("Write something");
    } else {
        let li = document.createElement("li"); // Fix: Change "lis" to "li"
        li.innerHTML = inputb.value;
        listc.appendChild(li);
        
        let span = document.createElement("span");
        span.innerHTML = "\u00d7";
        li.appendChild(span);
    }
    inputb.value="";
    savedata();

}
listc.addEventListener("click",function(e){
    if(e.target.tagName==="LI"){
        e.target.classList.toggle("checked");
        savedata();
    }
    else if(e.target.tagName==="SPAN"){
        e.target.parentElement.remove();
        savedata();
    }
},false);
function savedata(){
    localStorage.setItem("data",listc.innerHTML);
}
function showtask(){
    listc.innerHTML=localStorage.getItem("data");
}
showtask();
